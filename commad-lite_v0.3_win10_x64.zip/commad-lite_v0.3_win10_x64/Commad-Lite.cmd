
title Command-Lite v.0.3
echo Command-Lite v.0.3
echo.
echo (c) 2025 @Efe103 GitHub, @Efe103 
cd Tools
echo.
echo Command-Lite version includes only 3 commands, hence the "Lite" designation. This system also incorporates Windows Command Prompt commands. Commands: bios-info, version.
start cmd.exe 
