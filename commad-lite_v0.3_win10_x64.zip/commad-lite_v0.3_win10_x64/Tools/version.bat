@echo off
echo Windows Version:
ver
pause