@echo off
echo BIOS Info:
wmic bios get manufacturer, smbiosbiosversion
pause